<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $table = 'usuarios';
    protected $primaryKey = 'id_usuario';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'nome',
        'email',
        'senha', // usarei 'senha' para todos menos o admin@admin(senha 'admin'), então precisamos manter esse nome aqui.
        'telefone',
        'data_nascimento',
        'cpf',
        'saldo',
        'foto',
        'admin',
        'created_by',
    ];

    protected $hidden = [
        'senha',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'senha' => 'hashed',
            'data_nascimento' => 'date',
            'admin' => 'boolean',
            'saldo' => 'decimal:2',
        ];
    }

    /**
     * O Laravel busca por 'password' para logar. 
     * Como usamos 'senha', precisamos avisar o sistema:
     */
    public function getAuthPassword()
    {
        return $this->senha;
    }
    
    public function criador(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by', 'id_usuario');
    }

    public function produtos(): HasMany
    {
        return $this->hasMany(Product::class, 'vendedor_id', 'id_usuario');
    }

    
    public function enderecos(): HasMany
    {
        // migration defines the FK column as usuarios_id_usuario
        return $this->hasMany(Endereco::class, 'usuarios_id_usuario', 'id_usuario');
    }

    public function ComprasUsuario(): HasMany 
    {
        return $this->hasMany(Compra::class, 'id_comprador', 'id_usuario');
    }

    public function VendasAdmin(): HasMany 
    {
        return $this->hasMany(Compra::class, 'id_vendedor', 'id_usuario');
    }
}